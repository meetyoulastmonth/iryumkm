package com.ten.user;

public class SC {
	private int SNo;
	private int CNo;
	private String classroom;
	public int getSNo() {
		return SNo;
	}
	public void setSNo(int sNo) {
		SNo = sNo;
	}
	public int getCNo() {
		return CNo;
	}
	public void setCNo(int cNo) {
		CNo = cNo;
	}
	public String getClassroom() {
		return classroom;
	}
	public void setClassroom(String classroom) {
		this.classroom = classroom;
	}
	/**
	 * @param sNo
	 * @param cNo
	 * @param classroom
	 *
	public SC(int sNo, int cNo, String classroom) {
		SNo = sNo;
		CNo = cNo;
		this.classroom = classroom;
	}
	public SC() {
	}
	*/
	

}
